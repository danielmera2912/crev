module.exports = {
    publicPath: '/crev',
  }