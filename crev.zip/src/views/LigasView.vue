<script setup>
import Competiciones from '../components/Competiciones.vue'
</script>
<template>
  <main>
    <Competiciones />
  </main>
</template>
