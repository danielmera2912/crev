<template>
  <a class="torneo">
    <div class="torneo__tipo">
      Torneo
    </div>
    <div class="torneo__datos">
        
        <img class="torneo__datos__logo" src="https://d1csarkz8obe9u.cloudfront.net/posterpreviews/lion-fire-logo-design-template-free-89daa14626ac403bd3cf6282036663ff_screen.jpg?ts=1572094154"/>
        <div class="torneo__datos__nombre">Torneo de la copa avestruz</div>
      <div class="torneo__datos__actividad">En curso</div>
        <div class="torneo__datos__creador">Creado por Juan Perez</div>
        <div class="torneo__datos__participantes">16 participantes</div>
      </div>
  </a>
</template>
